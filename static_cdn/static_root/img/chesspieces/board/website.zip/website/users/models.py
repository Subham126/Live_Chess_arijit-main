from django.db import models

# Create your models here.
class SavedEmbeds(models.Model):
    api_url = models.URLField()
    name = models.CharField(max_length=100)
    description = models.TextField()
    