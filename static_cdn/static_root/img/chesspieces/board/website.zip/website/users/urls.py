from django.urls import path

from .views import home_view, signup_view, dashboard_view , test , test2 , test4, fen,dashboard_view1,shweta_test,embed
app_name = "users"

urlpatterns = [
    path('', home_view, name='home'),
    path('signup/', signup_view, name='sign-up'),
    path('dashboard/', dashboard_view, name='dashboard'),
    path('dashboard1/', dashboard_view1, name='dashboard1'),
    path('test/', test, name='test'),
    path('test2/', test2, name='test2'),
    path('test4/', test4, name='test4'),
    path('fen/', fen, name='fen'),
    path('testing/',shweta_test,name='shweta_test'),
    path('embed/',embed,name='embed'),
]
