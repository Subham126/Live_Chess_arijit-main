from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .forms import SignUpForm
from django.conf import settings

import requests


from .forms import SubmitEmbed
from .serializer import EmbedSerializer

def signup_view(request):
	if request.user.is_authenticated:
		return redirect('users:dashboard')
	if request.method == "POST":
		form = SignUpForm(request.POST)
		if form.is_valid():
			form.save()
			username = form.cleaned_data.get('username')
			firstname = form.cleaned_data.get('firstname')
			lastname = form.cleaned_data.get('lastname')
			password = form.cleaned_data.get('password1')
			user = authenticate(username=username, password=password, firstname = firstname,lastname=lastname)
			login(request, user)
			return redirect('users:dashboard')
		else:
			messages.error(request, 'Correct the errors below')
	else:
		form = SignUpForm()

	return render(request, 'app/signup.html', {'form': form})                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  


@login_required
def dashboard_view(request):
	return render(request, 'app/dashboard1.html')

def dashboard_view1(request):
	return render(request, 'app/dashboard1.html')

def home_view(request):
	return render(request, 'app/home.html')

def test(request):
	return render(request, 'app/test.html')



def test2(request):
	return render(request, 'app/test2.html')



def test4(request):
	return render(request, 'app/test4.html')	
import berserk

def fen(request):
	# session = berserk.TokenSession('RboOwEdRt7C5fEhX')
	# client = berserk.Client(session=session)
	



	if request.method == "POST":
		form = SubmitEmbed(request.POST)
		if form.is_valid():
			url = form.cleaned_data['url']
			r = requests.get('https://lichess.org/broadcast/new')
			json = r.json()
			serializer = EmbedSerializer(data=json)
			if serializer.is_valid():
				embed = serializer.save()
				return render(request, 'app/embeds.html', {'embed': embed})
	else:
		form = SubmitEmbed()

	return render(request, 'app/fen.html', {'form': form})		
        
			
def embed(request):
	return render(request, 'app/embed.html')	            
            
            
            
                
                
    
        

    

def shweta_test(request):
	return render(request,'app/testing.html')
