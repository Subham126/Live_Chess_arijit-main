chess24_board_theme = ['#9E7863', '#633526'];
metro_board_theme = ['#EFEFEF', '#FFFFFF'];
leipzig_board_theme = ['#FFFFFF', '#E1E1E1'];
wikipedia_board_theme = ['#D18B47', '#FFCE9E'];
dilena_board_theme = ['#FFE5B6', '#B16228'];
uscf_board_theme = ['#C3C6BE', '#727FA2'];
symbol_board_theme = ['#FFFFFF', '#58AC8A'];
